# Beatbox MIDI Web App

React app that records beatboxing, classifies sounds, and exports MIDI.